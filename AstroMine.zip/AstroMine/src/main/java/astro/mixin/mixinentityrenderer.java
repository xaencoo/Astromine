package astro.mixin;

import astro.core.ModuleManager;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderer.class)
public class MixinEntityRenderer {

    @Inject(method = "isVisible", at = @At("HEAD"), cancellable = true)
    private void forceVisible(Entity entity, CallbackInfoReturnable<Boolean> cir) {
        var module = ModuleManager.get("InvisibleESP");
        if (module != null && module.isEnabled()) {
            cir.setReturnValue(true);
        }
    }
}