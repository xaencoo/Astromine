package astro.mixin;

import astro.core.ModuleManager;
import net.minecraft.client.entity.player.AbstractClientPlayerEntity;
import net.minecraft.client.renderer.IRenderTypeBuffer;
import net.minecraft.client.renderer.entity.PlayerRenderer;
import com.mojang.blaze3d.matrix.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerRenderer.class)
public class MixinRenderPlayer {

    @Inject(method = "render", at = @At("HEAD"))
    private void preRender(AbstractClientPlayerEntity player, float yaw,
                           float partialTicks, MatrixStack ms,
                           IRenderTypeBuffer buffer, int light, CallbackInfo ci) {
        var chams = ModuleManager.get("Chams");
        if (chams != null && chams.isEnabled()) {
            // отключение depth test для рендера через стены
            com.mojang.blaze3d.systems.RenderSystem.disableDepthTest();
        }
    }
}