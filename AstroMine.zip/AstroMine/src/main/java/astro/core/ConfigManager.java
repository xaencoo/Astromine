package astro.core;

import com.google.gson.*;
import astro.modules.BaseModule;
import java.io.*;
import java.nio.file.*;

public class ConfigManager {
    private static final Path CONFIG = Paths.get("config/astromine.json");

    public static void save() {
        JsonObject obj = new JsonObject();
        for (BaseModule m : ModuleManager.modules) {
            obj.addProperty(m.getName(), m.isEnabled());
        }
        try {
            Files.createDirectories(CONFIG.getParent());
            Files.write(CONFIG, obj.toString().getBytes());
        } catch (IOException e) { e.printStackTrace(); }
    }

    public static void load() {
        if (!Files.exists(CONFIG)) return;
        try {
            String content = new String(Files.readAllBytes(CONFIG));
            JsonObject obj = JsonParser.parseString(content).getAsJsonObject();
            for (BaseModule m : ModuleManager.modules) {
                if (obj.has(m.getName())) {
                    boolean enabled = obj.get(m.getName()).getAsBoolean();
                    if (m.isEnabled() != enabled) m.toggle();
                }
            }
        } catch (IOException e) { e.printStackTrace(); }
    }
}