package astro.core.gui;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;

public class ModuleButton {
    private final String name;
    private final int x, y;
    private final int width;
    private final int height = 30;
    private boolean enabled;
    private float toggleAnim = 0f;
    private float hoverAnim = 0f;

    public ModuleButton(String name, int x, int y, int width, boolean enabled) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.width = width;
        this.enabled = enabled;
        this.toggleAnim = enabled ? 1f : 0f;
    }

    public void render(MatrixStack ms, int mouseX, int mouseY) {
        Minecraft mc = Minecraft.getInstance();

        boolean hovered = mouseX >= x && mouseX <= x + width
                       && mouseY >= y && mouseY <= y + height;

        // анимации
        float targetHover = hovered ? 1f : 0f;
        hoverAnim = AnimationUtils.lerp(hoverAnim, targetHover, 0.15f);
        toggleAnim = AnimationUtils.lerp(toggleAnim, enabled ? 1f : 0f, 0.2f);

        // фон
        int bgColor = AnimationUtils.lerpColor(
                ColorPalette.BG_PANEL,
                ColorPalette.BG_HOVER,
                hoverAnim);

        mc.gui.fill(ms, x, y, x + width, y + height, bgColor);

        // левая цветная полоска (индикатор вкл/выкл)
        int leftColor = AnimationUtils.lerpColor(
                ColorPalette.STATUS_OFF,
                ColorPalette.PURPLE_LIGHT,
                toggleAnim);
        mc.gui.fill(ms, x, y, x + 3, y + height, leftColor);

        // glow при включении
        if (toggleAnim > 0.1f) {
            int glow = AnimationUtils.lerpColor(0x00000000, ColorPalette.STATUS_ON_GLOW,
                    toggleAnim);
            mc.gui.fill(ms, x + 3, y, x + width, y + 2, glow);
            mc.gui.fill(ms, x + 3, y + height - 2, x + width, y + height, glow);
        }

        // текст
        int textColor = enabled ? ColorPalette.TEXT_WHITE : ColorPalette.TEXT_GRAY;
        mc.font.draw(ms, name, x + 12, y + 11, textColor);

        // переключатель справа
        renderToggle(ms, x + width - 40, y + 8);

        // пульсирующий индикатор ON
        if (enabled) {
            float pulse = AnimationUtils.pulse(1200);
            int dotColor = AnimationUtils.lerpColor(
                    ColorPalette.PURPLE_MAIN, ColorPalette.PINK_ACCENT, pulse);
            mc.gui.fill(ms, x + width - 12, y + 13, x + width - 8, y + 17, dotColor);
        }
    }

    private void renderToggle(MatrixStack ms, int tx, int ty) {
        Minecraft mc = Minecraft.getInstance();
        int tw = 26, th = 12;

        // фон переключателя
        int bg = AnimationUtils.lerpColor(
                ColorPalette.STATUS_OFF,
                ColorPalette.PURPLE_MAIN,
                toggleAnim);
        mc.gui.fill(ms, tx, ty, tx + tw, ty + th, bg);

        // круглый бегунок
        int knobX = (int) AnimationUtils.lerp(tx + 2, tx + tw - 10, toggleAnim);
        mc.gui.fill(ms, knobX, ty + 2, knobX + 8, ty + th - 2, 0xFFFFFFFF);

        // glow под переключателем
        if (toggleAnim > 0.3f) {
            int glow = AnimationUtils.lerpColor(0x00000000, ColorPalette.STATUS_ON_GLOW,
                    toggleAnim * 0.5f);
            mc.gui.fill(ms, tx - 2, ty - 2, tx + tw + 2, ty + th + 2, glow);
        }
    }

    public boolean isHovered(int mouseX, int mouseY) {
        return mouseX >= x && mouseX <= x + width
            && mouseY >= y && mouseY <= y + height;
    }

    public void toggle() {
        enabled = !enabled;
    }

    public boolean isEnabled() { return enabled; }
}