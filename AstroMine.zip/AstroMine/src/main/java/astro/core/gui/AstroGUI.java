package astro.core.gui;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.util.text.StringTextComponent;
import astro.core.ModuleManager;
import astro.modules.BaseModule;

import java.util.ArrayList;
import java.util.List;

public class AstroGUI extends Screen {
    private final List<CategoryPanel> categories = new ArrayList<>();
    private CategoryPanel activeCategory;
    private int guiX, guiY, guiW, guiH;
    private long openTime;

    public AstroGUI() {
        super(new StringTextComponent("AstroMine"));
    }

    @Override
    protected void init() {
        openTime = System.currentTimeMillis();

        guiW = 520;
        guiH = 320;
        guiX = (width - guiW) / 2;
        guiY = (height - guiH) / 2;

        categories.clear();
        categories.add(new CategoryPanel("Combat",   guiX + 10, guiY + 50));
        categories.add(new CategoryPanel("Movement", guiX + 10, guiY + 90));
        categories.add(new CategoryPanel("Render",   guiX + 10, guiY + 130));
        categories.add(new CategoryPanel("Player",   guiX + 10, guiY + 170));
        categories.add(new CategoryPanel("Util",     guiX + 10, guiY + 210));
        categories.add(new CategoryPanel("Configs",  guiX + 10, guiY + 250));

        activeCategory = categories.get(0);
    }

    @Override
    public void render(MatrixStack ms, int mouseX, int mouseY, float partial) {
        fill(ms, 0, 0, width, height, 0x88000000);

        float t = Math.min(1f, (System.currentTimeMillis() - openTime) / 250f);
        float ease = AnimationUtils.easeOut(t);
        int alpha = (int) (255 * ease);

        renderMainPanel(ms, alpha);
        renderTitle(ms, alpha);

        for (CategoryPanel c : categories) {
            c.render(ms, mouseX, mouseY, c == activeCategory);
        }

        renderModulesPanel(ms, mouseX, mouseY);

        super.render(ms, mouseX, mouseY, partial);
    }

    private void renderMainPanel(MatrixStack ms, int alpha) {
        for (int i = 8; i > 0; i--) {
            int glow = AnimationUtils.lerpColor(0x00000000, ColorPalette.BORDER_GLOW, (float) i / 8);
            fill(ms, guiX - i, guiY - i, guiX + guiW + i, guiY + guiH + i, glow);
        }

        fill(ms, guiX, guiY, guiX + guiW, guiY + guiH, ColorPalette.BG_PANEL);
        drawBorder(ms, guiX, guiY, guiW, guiH, ColorPalette.BORDER_PURPLE);
        fill(ms, guiX, guiY, guiX + guiW, guiY + 40, ColorPalette.BG_HEADER);

        for (int i = 0; i < 40; i++) {
            int[] rgb = ColorPalette.gradient((float) i / 40);
            int color = 0xFF000000 | (rgb[0] << 16) | (rgb[1] << 8) | rgb[2];
            fill(ms, guiX + i, guiY + 40, guiX + i + 1, guiY + 42, color);
        }
    }

    private void renderTitle(MatrixStack ms, int alpha) {
        String title = "AstroMine";
        int x = guiX + 20;
        int y = guiY + 15;

        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                if (dx == 0 && dy == 0) continue;
                font.draw(ms, title, x + dx, y + dy, 0x88EC4899);
            }
        }

        drawGradientString(ms, title, x, y);
    }

    private void drawGradientString(MatrixStack ms, String text, int x, int y) {
        int charX = x;
        for (int i = 0; i < text.length(); i++) {
            float t = (float) i / text.length();
            int[] rgb = ColorPalette.gradient(t);
            int color = 0xFF000000 | (rgb[0] << 16) | (rgb[1] << 8) | rgb[2];
            String c = String.valueOf(text.charAt(i));
            font.draw(ms, c, charX, y, color);
            charX += font.width(c);
        }
    }

    private void renderModulesPanel(MatrixStack ms, int mouseX, int mouseY) {
        int panelX = guiX + 130;
        int panelY = guiY + 50;
        int panelW = guiW - 140;
        int panelH = guiH - 60;

        fill(ms, panelX, panelY, panelX + panelW, panelY + panelH, ColorPalette.BG_DARK);
        drawBorder(ms, panelX, panelY, panelW, panelH, ColorPalette.BORDER_GLOW);

        font.draw(ms, activeCategory.getName(), panelX + 10, panelY + 8, ColorPalette.PINK_ACCENT);
    }

    private void drawBorder(MatrixStack ms, int x, int y, int w, int h, int color) {
        fill(ms, x, y, x + w, y + 1, color);
        fill(ms, x, y + h - 1, x + w, y + h, color);
        fill(ms, x, y, x + 1, y + h, color);
        fill(ms, x + w - 1, y, x + w, y + h, color);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}