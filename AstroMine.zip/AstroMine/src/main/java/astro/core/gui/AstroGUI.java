package astro.core.gui;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.util.text.StringTextComponent;
import astro.core.ModuleManager;
import astro.modules.BaseModule;

public class AstroGUI extends Screen {
    public AstroGUI() { super(new StringTextComponent("AstroMine")); }

    @Override
    protected void init() {
        int y = 20;
        for (BaseModule m : ModuleManager.modules) {
            addButton(new Button(width / 2 - 80, y, 160, 20,
                new StringTextComponent(m.getName() + (m.isEnabled() ? " §a[ON]" : " §c[OFF]")),
                b -> {
                    m.toggle();
                    b.setMessage(new StringTextComponent(
                        m.getName() + (m.isEnabled() ? " §a[ON]" : " §c[OFF]")));
                }));
            y += 22;
        }
    }

    @Override
    public boolean isPauseScreen() { return false; }
}