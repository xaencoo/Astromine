package astro.core.gui;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;

public class CategoryPanel {
    private final String name;
    private final int x, y;
    private final int width = 110;
    private final int height = 32;
    private float hoverAnim = 0f;

    public CategoryPanel(String name, int x, int y) {
        this.name = name;
        this.x = x;
        this.y = y;
    }

    public void render(MatrixStack ms, int mouseX, int mouseY, boolean active) {
        Minecraft mc = Minecraft.getInstance();
        boolean hovered = mouseX >= x && mouseX <= x + width
                       && mouseY >= y && mouseY <= y + height;

        // анимация наведения
        float target = hovered || active ? 1f : 0f;
        hoverAnim = AnimationUtils.lerp(hoverAnim, target, 0.15f);

        // фон
        int bg = AnimationUtils.lerpColor(ColorPalette.BG_PANEL, ColorPalette.BG_HOVER, hoverAnim);
        int leftBar = AnimationUtils.lerpColor(0x00000000, ColorPalette.PURPLE_MAIN, hoverAnim);

        mc.gui.fill(ms, x, y, x + width, y + height, bg);

        // левая полоска-индикатор
        mc.gui.fill(ms, x, y, x + 3, y + height, leftBar);

        // свечение при активной
        if (active) {
            float pulse = AnimationUtils.pulse(1500);
            int glow = AnimationUtils.lerpColor(0x00000000, ColorPalette.PINK_GLOW,
                    (int) (pulse * 100) / 100f);
            mc.gui.fill(ms, x - 1, y - 1, x + width + 1, y + height + 1, glow);
        }

        // текст
        int textColor = active ? ColorPalette.TEXT_WHITE : ColorPalette.TEXT_GRAY;
        mc.font.draw(ms, name, x + 12, y + 12, textColor);
    }

    public String getName() { return name; }
    public int getY() { return y; }
    public boolean isHovered(int mouseX, int mouseY) {
        return mouseX >= x && mouseX <= x + width
            && mouseY >= y && mouseY <= y + height;
    }
}