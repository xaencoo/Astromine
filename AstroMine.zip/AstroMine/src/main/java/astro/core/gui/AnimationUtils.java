package astro.core.gui;

public class AnimationUtils {
    public static float lerp(float from, float to, float t) {
        return from + (to - from) * t;
    }

    public static int lerpColor(int c1, int c2, float t) {
        int a1 = (c1 >> 24) & 0xFF, r1 = (c1 >> 16) & 0xFF, g1 = (c1 >> 8) & 0xFF, b1 = c1 & 0xFF;
        int a2 = (c2 >> 24) & 0xFF, r2 = (c2 >> 16) & 0xFF, g2 = (c2 >> 8) & 0xFF, b2 = c2 & 0xFF;
        int a = (int) (a1 + (a2 - a1) * t);
        int r = (int) (r1 + (r2 - r1) * t);
        int g = (int) (g1 + (g2 - g1) * t);
        int b = (int) (b1 + (b2 - b1) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public static float easeOut(float t) {
        return 1f - (1f - t) * (1f - t);
    }

    public static float easeInOut(float t) {
        return t < 0.5f ? 2f * t * t : 1f - (float) Math.pow(-2f * t + 2f, 2f) / 2f;
    }

    public static float pulse(long periodMs) {
        long time = System.currentTimeMillis() % periodMs;
        float t = (float) time / periodMs;
        return (float) (Math.sin(t * Math.PI * 2) * 0.5 + 0.5);
    }
}