package astro.core.gui;

public class ColorPalette {
    // Основной фиолетовый
    public static final int PURPLE_MAIN      = 0xFF8B5CF6;
    public static final int PURPLE_DARK      = 0xFF5B21B6;
    public static final int PURPLE_LIGHT     = 0xFFA855F7;

    // Акцент — неоново-розовый
    public static final int PINK_ACCENT      = 0xFFEC4899;
    public static final int PINK_GLOW        = 0x88EC4899;

    // Фон
    public static final int BG_DARK          = 0xDD0D0D1A;
    public static final int BG_PANEL         = 0xCC141428;
    public static final int BG_HOVER         = 0xCC1E1E3A;
    public static final int BG_HEADER        = 0xEE1A1A2E;

    // Границы
    public static final int BORDER_PURPLE    = 0xFF8B5CF6;
    public static final int BORDER_GLOW      = 0x448B5CF6;

    // Текст
    public static final int TEXT_WHITE       = 0xFFFFFFFF;
    public static final int TEXT_GRAY        = 0xFFB0B0C0;
    public static final int TEXT_DARK        = 0xFF606070;

    // Статусы
    public static final int STATUS_ON        = 0xFF8B5CF6;
    public static final int STATUS_ON_GLOW   = 0x558B5CF6;
    public static final int STATUS_OFF       = 0xFF3A3A4A;
    public static final int STATUS_OFF_DOT   = 0xFF606070;

    // Градиент
    public static int[] gradient(float t) {
        int r = (int) (0x8B + (0xEC - 0x8B) * t);
        int g = (int) (0x5C + (0x48 - 0x5C) * t);
        int b = (int) (0xF6 + (0x99 - 0xF6) * t);
        return new int[]{r, g, b};
    }
}