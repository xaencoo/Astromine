package astro.core.gui;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;

public class SettingsPanel {
    private final int x, y, width, height;

    public SettingsPanel(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void render(MatrixStack ms, int mouseX, int mouseY) {
        Minecraft mc = Minecraft.getInstance();

        // фон
        mc.gui.fill(ms, x, y, x + width, y + height, ColorPalette.BG_DARK);

        // рамка с фиолетовым свечением
        for (int i = 3; i > 0; i--) {
            int glow = AnimationUtils.lerpColor(0x00000000, ColorPalette.BORDER_GLOW,
                    (float) i / 3);
            mc.gui.fill(ms, x - i, y - i, x + width + i, y + height + i, glow);
        }
        drawBorder(ms, x, y, width, height, ColorPalette.BORDER_PURPLE);

        // заголовок
        mc.font.draw(ms, "§dНастройки", x + 10, y + 8, ColorPalette.TEXT_WHITE);

        // демо-слайдер
        renderSlider(ms, "Громкость", x + 10, y + 40, 100, 0.65f);
    }

    private void renderSlider(MatrixStack ms, String label, int sx, int sy, int sw, float value) {
        Minecraft mc = Minecraft.getInstance();

        mc.font.draw(ms, label, sx, sy - 10, ColorPalette.TEXT_GRAY);

        // трек
        mc.gui.fill(ms, sx, sy, sx + sw, sy + 4, ColorPalette.STATUS_OFF);

        // заполненная часть
        int filled = (int) (sw * value);
        for (int i = 0; i < filled; i++) {
            float t = (float) i / sw;
            int[] rgb = ColorPalette.gradient(t);
            int c = 0xFF000000 | (rgb[0] << 16) | (rgb[1] << 8) | rgb[2];
            mc.gui.fill(ms, sx + i, sy, sx + i + 1, sy + 4, c);
        }

        // ползунок
        int knobX = sx + filled - 3;
        mc.gui.fill(ms, knobX, sy - 3, knobX + 6, sy + 7, ColorPalette.PINK_ACCENT);

        // glow вокруг ползунка
        int glow = AnimationUtils.lerpColor(0x00000000, ColorPalette.PINK_GLOW, 0.6f);
        mc.gui.fill(ms, knobX - 4, sy - 6, knobX + 10, sy + 10, glow);
    }

    private void drawBorder(MatrixStack ms, int x, int y, int w, int h, int color) {
        Minecraft mc = Minecraft.getInstance();
        mc.gui.fill(ms, x, y, x + w, y + 1, color);
        mc.gui.fill(ms, x, y + h - 1, x + w, y + h, color);
        mc.gui.fill(ms, x, y, x + 1, y + h, color);
        mc.gui.fill(ms, x + w - 1, y, x + w, y + h, color);
    }
}