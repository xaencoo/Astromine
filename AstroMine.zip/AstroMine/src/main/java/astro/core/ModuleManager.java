package astro.core;

import astro.modules.BaseModule;
import astro.modules.visual.*;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import java.util.*;

public class ModuleManager {
    public static List<BaseModule> modules = new ArrayList<>();

    public static void registerAll() {
        modules.add(new HealthDisplay());
        modules.add(new InvisibleESP());
        modules.add(new ESPBox());
        modules.add(new ESPTracers());
        modules.add(new Nametags());
        modules.add(new Chams());
        modules.add(new ItemESP());
        modules.add(new ChestESP());
        modules.add(new Trajectory());
        modules.add(new DamageNumbers());
        modules.add(new Fullbright());
        modules.add(new TargetHUD());
        modules.add(new PlayerScanner());
        modules.add(new ArmorHUD());
        modules.add(new Waypoints());
    }

    public static BaseModule get(String name) {
        return modules.stream().filter(m -> m.getName().equals(name)).findFirst().orElse(null);
    }

    public static void onTick() {
        for (BaseModule m : modules) if (m.isEnabled()) m.onTick();
    }

    public static void onRenderWorld(RenderWorldLastEvent event) {
        for (BaseModule m : modules) if (m.isEnabled()) m.onRenderWorld(event);
    }

    public static void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        for (BaseModule m : modules) if (m.isEnabled()) m.onRenderOverlay(event);
    }
}