package astro.core;

import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import org.lwjgl.glfw.GLFW;

public class KeybindManager {
    public static KeyBinding openGUI;

    public static void register() {
        openGUI = new KeyBinding("Open AstroMine GUI", GLFW.GLFW_KEY_RIGHT_SHIFT, "AstroMine");
        ClientRegistry.registerKeyBinding(openGUI);
    }
}