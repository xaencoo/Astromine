package astro;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import astro.core.KeybindManager;
import astro.core.ModuleManager;
import astro.core.gui.AstroGUI;

public class EventHandler {

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        ModuleManager.onTick();
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        ModuleManager.onRenderWorld(event);
    }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        ModuleManager.onRenderOverlay(event);
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent event) {
        while (KeybindManager.openGUI.consumeClick()) {
            Minecraft.getInstance().setScreen(new AstroGUI());
        }
    }
}