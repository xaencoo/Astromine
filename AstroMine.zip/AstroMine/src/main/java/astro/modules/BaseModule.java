package astro.modules;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public abstract class BaseModule {
    protected static final Minecraft mc = Minecraft.getInstance();
    private final String name;
    private boolean enabled = true;

    public BaseModule(String name) { this.name = name; }

    public String getName() { return name; }
    public boolean isEnabled() { return enabled; }
    public void toggle() { enabled = !enabled; }

    public void onTick() {}
    public void onRenderWorld(RenderWorldLastEvent event) {}
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {}
}