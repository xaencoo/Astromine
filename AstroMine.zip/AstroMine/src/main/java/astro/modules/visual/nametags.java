package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraftforge.client.event.RenderNameplateEvent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class Nametags extends BaseModule {
    public Nametags() { super("Nametags"); }

    @SubscribeEvent
    public void onNameplate(RenderNameplateEvent event) {
        if (!(event.getEntity() instanceof PlayerEntity)) return;
        PlayerEntity p = (PlayerEntity) event.getEntity();
        if (p == mc.player) return;

        float hp = p.getHealth();
        float dist = mc.player.getDistance(p);
        int armor = p.getTotalArmorValue();
        String tag = String.format("§b%s §7| §c%.1f❤ §7| §9%d🛡 §7| §f%.1fm",
            p.getName().getString(), hp, armor, dist);

        event.setContent(new StringTextComponent(tag));
    }
}