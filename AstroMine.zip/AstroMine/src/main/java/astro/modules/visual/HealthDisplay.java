package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.entity.LivingEntity;
import net.minecraftforge.client.event.RenderNameplateEvent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class HealthDisplay extends BaseModule {
    public HealthDisplay() { super("HealthDisplay"); }

    @SubscribeEvent
    public void onNameplate(RenderNameplateEvent event) {
        if (!(event.getEntity() instanceof LivingEntity)) return;
        LivingEntity e = (LivingEntity) event.getEntity();
        if (e == mc.player) return;

        float hp = e.getHealth();
        float max = e.getMaxHealth();
        String color = hp > max * 0.66f ? "§a" : hp > max * 0.33f ? "§e" : "§c";
        String text = color + String.format("%.1f", hp) + " §7/ §f" + max + " ❤";

        event.setContent(new StringTextComponent(
            event.getContent().getString() + "\n" + text));
    }
}