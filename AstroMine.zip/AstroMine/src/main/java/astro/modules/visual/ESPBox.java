package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public class ESPBox extends BaseModule {
    public ESPBox() { super("ESPBox"); }

    @Override
    public void onRenderWorld(RenderWorldLastEvent event) {
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof PlayerEntity) || e == mc.player) continue;
            // отрисовка AABB
        }
    }
}