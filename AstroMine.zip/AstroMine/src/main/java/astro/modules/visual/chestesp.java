package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.tileentity.ChestTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import com.mojang.blaze3d.matrix.MatrixStack;

public class ChestESP extends BaseModule {
    public ChestESP() { super("ChestESP"); }

    @Override
    public void onRenderWorld(RenderWorldLastEvent event) {
        MatrixStack ms = event.getMatrixStack();
        for (TileEntity te : mc.world.loadedTileEntityList) {
            if (te instanceof ChestTileEntity) {
                // renderBox(ms, te.getPos(), 1f, 1f, 0f);
            }
        }
    }
}