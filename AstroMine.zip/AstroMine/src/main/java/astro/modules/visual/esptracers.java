package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public class ESPTracers extends BaseModule {
    public ESPTracers() { super("ESPTracers"); }

    @Override
    public void onRenderWorld(RenderWorldLastEvent event) {
        Vector3d cam = mc.gameRenderer.getActiveRenderInfo().getProjectedView();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            // отрисовка линии
        }
    }
}