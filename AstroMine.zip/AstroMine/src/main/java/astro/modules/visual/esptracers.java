package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import com.mojang.blaze3d.matrix.MatrixStack;

public class ESPTracers extends BaseModule {
    public ESPTracers() { super("ESPTracers"); }

    @Override
    public void onRenderWorld(RenderWorldLastEvent event) {
        MatrixStack ms = event.getMatrixStack();
        Vector3d cam = mc.gameRenderer.getActiveRenderInfo().getProjectedView();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            // линия от камеры к цели
        }
    }
}