package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.item.BowItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import com.mojang.blaze3d.matrix.MatrixStack;

public class Trajectory extends BaseModule {
    public Trajectory() { super("Trajectory"); }

    @Override
    public void onRenderWorld(RenderWorldLastEvent event) {
        MatrixStack ms = event.getMatrixStack();
        var item = mc.player.getHeldItemMainhand().getItem();
        if (!(item instanceof BowItem || item instanceof TridentItem
              || item == net.minecraft.item.Items.ENDER_PEARL)) return;

        Vector3d start = mc.player.getPositionVec().add(0, mc.player.getEyeHeight(), 0);
        Vector3d dir = mc.player.getLookVec().scale(0.5);
        Vector3d pos = start;
        for (int i = 0; i < 60; i++) {
            pos = pos.add(dir);
            dir = dir.add(0, -0.05, 0);
            // drawPoint(pos);
        }
    }
}