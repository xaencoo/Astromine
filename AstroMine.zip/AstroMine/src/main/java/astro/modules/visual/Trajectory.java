package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.item.BowItem;
import net.minecraft.item.Items;
import net.minecraft.item.TridentItem;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public class Trajectory extends BaseModule {
    public Trajectory() { super("Trajectory"); }

    @Override
    public void onRenderWorld(RenderWorldLastEvent event) {
        if (!(mc.player.getMainHandItem().getItem() instanceof BowItem
            || mc.player.getMainHandItem().getItem() instanceof TridentItem
            || mc.player.getMainHandItem().getItem() == Items.ENDER_PEARL)) return;

        Vector3d start = mc.player.position().add(0, mc.player.getEyeHeight(), 0);
        Vector3d dir = mc.player.getLookAngle().scale(0.5);
        Vector3d pos = start;
        for (int i = 0; i < 60; i++) {
            pos = pos.add(dir);
            dir = dir.add(0, -0.05, 0);
            // отрисовка точки
        }
    }
}