package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import com.mojang.blaze3d.matrix.MatrixStack;

public class InvisibleESP extends BaseModule {
    public InvisibleESP() { super("InvisibleESP"); }

    @Override
    public void onRenderWorld(RenderWorldLastEvent event) {
        MatrixStack ms = event.getMatrixStack();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !p.isInvisible()) continue;
            // Рисуем красную рамку (через AABB)
            renderBox(ms, p);
        }
    }

    private void renderBox(MatrixStack ms, PlayerEntity p) {
        // отрисовка AABB с цветом (1,0,0,1)
    }
}