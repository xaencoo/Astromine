package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import java.util.*;

public class Waypoints extends BaseModule {
    public static class WP {
        public String name;
        public double x, y, z;
        public int color;
        public WP(String n, double x, double y, double z, int c) {
            this.name = n; this.x = x; this.y = y; this.z = z; this.color = c;
        }
    }

    public static List<WP> points = new ArrayList<>();

    public Waypoints() { super("Waypoints"); }

    public static void add(String name) {
        points.add(new WP(name, mc.player.getX(), mc.player.getY(),
            mc.player.getZ(), 0x00FFAA));
    }

    @Override
    public void onRenderWorld(RenderWorldLastEvent event) {
        for (WP wp : points) {
            double dx = wp.x - mc.player.getX();
            double dy = wp.y - mc.player.getY();
            double dz = wp.z - mc.player.getZ();
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dist > 300) continue;
            // отрисовка
        }
    }
}