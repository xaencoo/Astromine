package astro.modules.visual;

import astro.modules.BaseModule;

public class Chams extends BaseModule {
    public Chams() { super("Chams"); }
}