package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.item.Items;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import com.mojang.blaze3d.matrix.MatrixStack;

public class ItemESP extends BaseModule {
    public ItemESP() { super("ItemESP"); }

    @Override
    public void onRenderWorld(RenderWorldLastEvent event) {
        MatrixStack ms = event.getMatrixStack();
        for (ItemEntity item : mc.world.getEntitiesWithinAABB(ItemEntity.class,
                mc.player.getBoundingBox().grow(64))) {
            var stack = item.getItem();
            float r = 1f, g = 1f, b = 1f;
            if (stack.getItem() == Items.TOTEM_OF_UNDYING) { r = 1f; g = 0f; b = 1f; }
            else if (stack.getItem() == Items.END_CRYSTAL) { r = 1f; g = 0f; b = 1f; }
            else if (stack.getItem() == Items.ENCHANTED_GOLDEN_APPLE) { r = 1f; g = 1f; b = 0f; }
            // renderBox(ms, item, r, g, b);
        }
    }
}