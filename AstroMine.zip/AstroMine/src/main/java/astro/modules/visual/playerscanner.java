package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import com.mojang.blaze3d.matrix.MatrixStack;

public class PlayerScanner extends BaseModule {
    public PlayerScanner() { super("PlayerScanner"); }

    @Override
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        MatrixStack ms = event.getMatrixStack();
        int y = 5;
        mc.font.drawString(ms, "§b§l=== SCAN ===", 5, y, 0xFFFFFF);
        y += 12;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            float hp = p.getHealth();
            double dist = mc.player.getDistance(p);
            String color = hp > 15 ? "§a" : hp > 7 ? "§e" : "§c";
            mc.font.drawString(ms, color + p.getName().getString()
                + " §7| §f" + String.format("%.0f", hp) + "❤"
                + " §7| §f" + String.format("%.0f", dist) + "m", 5, y, 0xFFFFFF);
            y += 11;
            if (y > 200) break;
        }
    }
}