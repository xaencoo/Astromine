package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import com.mojang.blaze3d.matrix.MatrixStack;
import java.util.*;

public class Waypoints extends BaseModule {
    public static class WP {
        public String name;
        public double x, y, z;
        public int color;
        public WP(String n, double x, double y, double z, int c) {
            this.name = n; this.x = x; this.y = y; this.z = z; this.color = c;
        }
    }

    public static List<WP> points = new ArrayList<>();

    public Waypoints() { super("Waypoints"); }

    public static void add(String name) {
        points.add(new WP(name, mc.player.getPosX(), mc.player.getPosY(),
            mc.player.getPosZ(), 0x00FFAA));
    }

    @Override
    public void onRenderWorld(RenderWorldLastEvent event) {
        MatrixStack ms = event.getMatrixStack();
        for (WP wp : points) {
            double dx = wp.x - mc.player.getPosX();
            double dy = wp.y - mc.player.getPosY();
            double dz = wp.z - mc.player.getPosZ();
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dist > 300) continue;
            // render waypoint через RenderNameplateEvent или 2D overlay
        }
    }
}