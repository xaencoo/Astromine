package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.tileentity.ChestTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public class ChestESP extends BaseModule {
    public ChestESP() { super("ChestESP"); }

    @Override
    public void onRenderWorld(RenderWorldLastEvent event) {
        for (TileEntity te : mc.level.blockEntityList) {
            if (te instanceof ChestTileEntity) {
                // отрисовка
            }
        }
    }
}