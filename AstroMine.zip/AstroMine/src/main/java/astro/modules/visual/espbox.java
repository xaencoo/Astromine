package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import com.mojang.blaze3d.matrix.MatrixStack;

public class ESPBox extends BaseModule {
    public ESPBox() { super("ESPBox"); }

    @Override
    public void onRenderWorld(RenderWorldLastEvent event) {
        MatrixStack ms = event.getMatrixStack();
        for (Entity e : mc.world.getAllEntities()) {
            if (!(e instanceof PlayerEntity) || e == mc.player) continue;
            renderBox(ms, e, 0f, 1f, 1f);
        }
    }

    private void renderBox(MatrixStack ms, Entity e, float r, float g, float b) {
        // отрисовка AABB
    }
}