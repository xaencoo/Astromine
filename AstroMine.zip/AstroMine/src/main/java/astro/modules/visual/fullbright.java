package astro.modules.visual;

import astro.modules.BaseModule;

public class Fullbright extends BaseModule {
    private float oldGamma;

    public Fullbright() { super("Fullbright"); }

    @Override
    public void onTick() {
        if (isEnabled()) {
            mc.gameSettings.gamma = 100f;
        }
    }
}