package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public class InvisibleESP extends BaseModule {
    public InvisibleESP() { super("InvisibleESP"); }

    @Override
    public void onRenderWorld(RenderWorldLastEvent event) {
        for (PlayerEntity p : mc.level.players()) {
            if (p == mc.player || !p.isInvisible()) continue;
            // отрисовка через AABB — см. ESPBox
        }
    }
}