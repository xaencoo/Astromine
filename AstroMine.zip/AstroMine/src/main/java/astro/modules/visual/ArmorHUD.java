package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.EntityRayTraceResult;
import net.minecraftforge.client.event.RenderGameOverlayEvent;

public class ArmorHUD extends BaseModule {
    public ArmorHUD() { super("ArmorHUD"); }

    @Override
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        LivingEntity target = null;
        if (mc.hitResult instanceof EntityRayTraceResult) {
            Entity e = ((EntityRayTraceResult) mc.hitResult).getEntity();
            if (e instanceof LivingEntity) target = (LivingEntity) e;
        }
        if (target == null) target = mc.player;

        int x = mc.getWindow().getGuiScaledWidth() - 100;
        int y = mc.getWindow().getGuiScaledHeight() - 60;

        mc.font.draw(event.getMatrixStack(), "§7Armor:", x, y - 12, 0xFFFFFF);
        int i = 0;
        for (ItemStack stack : target.getArmorSlots()) {
            if (!stack.isEmpty()) {
                mc.getItemRenderer().renderAndDecorateItem(stack, x + i * 18, y);
                mc.getItemRenderer().renderGuiItemDecorations(mc.font, stack, x + i * 18, y);
            }
            i++;
        }
        mc.font.draw(event.getMatrixStack(),
            "§cHP: §f" + String.format("%.1f", target.getHealth()),
            x, y + 20, 0xFFFFFF);
    }
}