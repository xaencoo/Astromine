package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.RenderGameOverlayEvent;

public class ArmorHUD extends BaseModule {
    public ArmorHUD() { super("ArmorHUD"); }

    @Override
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        LivingEntity target = null;
        if (mc.pointedEntity instanceof LivingEntity) {
            target = (LivingEntity) mc.pointedEntity;
        }
        if (target == null) target = mc.player;

        int x = mc.getMainWindow().getScaledWidth() - 100;
        int y = mc.getMainWindow().getScaledHeight() - 60;

        mc.fontRenderer.drawString(event.getMatrixStack(), "§7Armor:", x, y - 12, 0xFFFFFF);
        int i = 0;
        for (ItemStack stack : target.getArmorInventoryList()) {
            if (!stack.isEmpty()) {
                mc.getItemRenderer().renderItemAndEffectIntoGUI(stack, x + i * 18, y);
                mc.getItemRenderer().renderItemOverlayIntoGUI(mc.fontRenderer, stack, x + i * 18, y, null);
            }
            i++;
        }
        mc.fontRenderer.drawString(event.getMatrixStack(), "§cHP: §f" + String.format("%.1f", target.getHealth()),
            x, y + 20, 0xFFFFFF);
    }
}