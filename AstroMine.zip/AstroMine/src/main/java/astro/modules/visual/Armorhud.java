package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import com.mojang.blaze3d.matrix.MatrixStack;

public class ArmorHUD extends BaseModule {
    public ArmorHUD() { super("ArmorHUD"); }

    @Override
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        MatrixStack ms = event.getMatrixStack();
        LivingEntity target = null;
        if (mc.objectMouseOver != null
            && mc.objectMouseOver.getEntity() instanceof LivingEntity) {
            target = (LivingEntity) mc.objectMouseOver.getEntity();
        }
        if (target == null) target = mc.player;

        int x = mc.getMainWindow().getScaledWidth() - 100;
        int y = mc.getMainWindow().getScaledHeight() - 60;

        mc.font.drawString(ms, "§7Armor:", x, y - 12, 0xFFFFFF);
        int i = 0;
        for (ItemStack stack : target.getArmorInventoryList()) {
            if (!stack.isEmpty()) {
                mc.getItemRenderer().renderItemAndEffectIntoGUI(stack, x + i * 18, y);
                mc.getItemRenderer().renderItemOverlayIntoGUI(
                    mc.font, stack, x + i * 18, y, null);
            }
            i++;
        }
        mc.font.drawString(ms, "§cHP: §f" + String.format("%.1f", target.getHealth()),
            x, y + 20, 0xFFFFFF);
    }
}