package astro.modules.visual;

import astro.modules.BaseModule;

public class Fullbright extends BaseModule {
    public Fullbright() { super("Fullbright"); }

    @Override
    public void onTick() {
        if (isEnabled()) {
            mc.options.gamma = 100f;
        }
    }
}