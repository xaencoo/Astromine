package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.entity.LivingEntity;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import java.util.*;

public class DamageNumbers extends BaseModule {
    private static class Entry {
        double x, y, z; int dmg, ticks;
        Entry(double x, double y, double z, int d) {
            this.x = x; this.y = y; this.z = z; this.dmg = d; this.ticks = 60;
        }
    }

    public static List<Entry> entries = new ArrayList<>();

    public DamageNumbers() { super("DamageNumbers"); }

    public static void onDamage(LivingEntity target, int amount) {
        entries.add(new Entry(target.getPosX(), target.getPosY() + 1,
            target.getPosZ(), amount));
    }

    @Override
    public void onRenderWorld(RenderWorldLastEvent event) {
        Iterator<Entry> it = entries.iterator();
        while (it.hasNext()) {
            Entry e = it.next();
            e.ticks--;
            e.y += 0.02;
            if (e.ticks <= 0) it.remove();
        }
    }
}