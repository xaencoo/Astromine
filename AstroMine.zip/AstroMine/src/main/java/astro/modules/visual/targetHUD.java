package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.entity.LivingEntity;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import com.mojang.blaze3d.matrix.MatrixStack;

public class TargetHUD extends BaseModule {
    public TargetHUD() { super("TargetHUD"); }

    @Override
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        MatrixStack ms = event.getMatrixStack();
        LivingEntity target = null;
        if (mc.objectMouseOver != null
            && mc.objectMouseOver.getEntity() instanceof LivingEntity) {
            target = (LivingEntity) mc.objectMouseOver.getEntity();
        }
        if (target == null) return;

        int x = 20, y = 100;
        mc.font.drawString(ms, "§cTarget: §f" + target.getName().getString(), x, y, 0xFFFFFF);
        mc.font.drawString(ms, "§cHP: §f" + String.format("%.1f", target.getHealth()), x, y + 12, 0xFFFFFF);
        mc.font.drawString(ms, "§cArmor: §f" + target.getTotalArmorValue(), x, y + 24, 0xFFFFFF);
        mc.font.drawString(ms, "§cDist: §f" + String.format("%.1f",
            mc.player.getDistance(target)) + "m", x, y + 36, 0xFFFFFF);
    }
}