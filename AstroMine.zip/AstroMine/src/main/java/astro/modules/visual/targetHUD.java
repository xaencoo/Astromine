package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.entity.LivingEntity;
import net.minecraftforge.client.event.RenderGameOverlayEvent;

public class TargetHUD extends BaseModule {
    public TargetHUD() { super("TargetHUD"); }

    @Override
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        LivingEntity target = null;
        if (mc.hitResult != null && mc.hitResult.getEntity() instanceof LivingEntity) {
            target = (LivingEntity) mc.hitResult.getEntity();
        }
        if (target == null) return;

        int x = 20, y = 100;
        mc.font.draw(event.getMatrixStack(), "§cTarget: §f" + target.getName().getString(), x, y, 0xFFFFFF);
        mc.font.draw(event.getMatrixStack(), "§cHP: §f" + String.format("%.1f", target.getHealth()), x, y + 12, 0xFFFFFF);
        mc.font.draw(event.getMatrixStack(), "§cArmor: §f" + target.getTotalArmorValue(), x, y + 24, 0xFFFFFF);
        mc.font.draw(event.getMatrixStack(), "§cDist: §f" + String.format("%.1f",
            mc.player.distanceTo(target)) + "m", x, y + 36, 0xFFFFFF);
    }
}