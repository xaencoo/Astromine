package astro.modules.visual;

import astro.modules.BaseModule;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public class ItemESP extends BaseModule {
    public ItemESP() { super("ItemESP"); }

    @Override
    public void onRenderWorld(RenderWorldLastEvent event) {
        for (ItemEntity item : mc.level.getEntitiesOfClass(ItemEntity.class,
                mc.player.getBoundingBox().inflate(64))) {
            ItemStack stack = item.getItem();
            float r = 1f, g = 1f, b = 1f;
            if (stack.getItem() == Items.TOTEM_OF_UNDYING) { r = 1f; g = 0f; b = 1f; }
            else if (stack.getItem() == Items.END_CRYSTAL) { r = 1f; g = 0f; b = 1f; }
            else if (stack.getItem() == Items.ENCHANTED_GOLDEN_APPLE) { r = 1f; g = 1f; b = 0f; }
            // отрисовка
        }
    }
}