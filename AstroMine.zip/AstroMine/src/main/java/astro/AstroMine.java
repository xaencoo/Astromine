package astro;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import astro.core.ModuleManager;
import astro.core.KeybindManager;

@Mod("astromine")
public class AstroMine {
    public AstroMine() {
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::onClientSetup);
    }

    private void onClientSetup(FMLClientSetupEvent event) {
        ModuleManager.registerAll();
        KeybindManager.register();
        MinecraftForge.EVENT_BUS.register(new EventHandler());
        System.out.println("[AstroMine] Visual client loaded");
    }
}